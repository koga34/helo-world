

    $('.navbar-toggle').click(function(){

        $('.topmenu').toggle();

    });
		$('.language-top').click(function(){

					$('.language-submenu').toggle()

    });
		$('.submenu-link').click(function(){

				$('.submenu').toggle();

		});



    $(document).ready(function() {

    	$('.image1').magnificPopup({
    		type: 'image',
    		closeOnContentClick: true,
    		mainClass: 'mfp-img-mobile',
    		image: {
    			verticalFit: true
    		}

    	});

    	$('.image2').magnificPopup({
    		type: 'image',
    		closeOnContentClick: true,
    		image: {
    			verticalFit: false
    		}
    	});
      $('.image4').magnificPopup({
        type: 'image',
        closeOnContentClick: true,
        image: {
          verticalFit: false
        }
      });
      $('.image5').magnificPopup({
        type: 'image',
        closeOnContentClick: true,
        image: {
          verticalFit: false
        }
      });
      $('.image6').magnificPopup({
        type: 'image',
        closeOnContentClick: true,
        image: {
          verticalFit: false
        }
      });
      $('.image7').magnificPopup({
        type: 'image',
        closeOnContentClick: true,
        image: {
          verticalFit: false
        }
      });
      $('.image8').magnificPopup({
        type: 'image',
        closeOnContentClick: true,
        image: {
          verticalFit: false
        }
      });
    	$('.image3').magnificPopup({
    		type: 'image',
    		closeOnContentClick: true,
    		closeBtnInside: false,
    		fixedContentPos: true,
    		mainClass: 'mfp-no-margins mfp-with-zoom', // class to remove default margin from left and right side
    		image: {
    			verticalFit: true
    		},
    		zoom: {
    			enabled: true,
    			duration: 300 // don't foget to change the duration also in CSS
    		}
    	});

    });
